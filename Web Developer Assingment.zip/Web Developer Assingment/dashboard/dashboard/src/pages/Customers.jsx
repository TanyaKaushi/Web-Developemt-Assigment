import React from "react";
import "../pages/page-style.css";

const Customers = () => {
  return (
    <div>
      <h3>Customer List</h3>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Phone</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>John Doe</td>
            <td>Administration</td>
            <td>(171) 555-2222</td>
            <td>
              <a
                class="add"
                title="Add"
                data-toggle="tooltip"
                style={{ marginRight: "30px" }}
              >
                <i
                  class="bi bi-pencil-fill"
                  style={{ font: "6rem", color: "grey" }}
                ></i>
              </a>
              <a class="delete" title="Delete" data-toggle="tooltip">
                <i
                  class="bi bi-trash-fill"
                  style={{ font: "2rem", color: "red" }}
                ></i>
              </a>
            </td>
          </tr>
          <tr>
            <td>Peter Parker</td>
            <td>Customer Service</td>
            <td>(313) 555-5735</td>
            <td>
              <a
                class="add"
                title="Add"
                data-toggle="tooltip"
                style={{ marginRight: "30px" }}
              >
                <i
                  class="bi bi-pencil-fill"
                  style={{ font: "6rem", color: "grey" }}
                ></i>
              </a>
              <a class="delete" title="Delete" data-toggle="tooltip">
                <i
                  class="bi bi-trash-fill"
                  style={{ font: "2rem", color: "red" }}
                ></i>
              </a>
            </td>
          </tr>
          <tr>
            <td>John Doe</td>
            <td>Administration</td>
            <td>(171) 555-2222</td>
            <td>
              <a
                class="add"
                title="Add"
                data-toggle="tooltip"
                style={{ marginRight: "30px" }}
              >
                <i
                  class="bi bi-pencil-fill"
                  style={{ font: "6rem", color: "grey" }}
                ></i>
              </a>
              <a class="delete" title="Delete" data-toggle="tooltip">
                <i
                  class="bi bi-trash-fill"
                  style={{ font: "2rem", color: "red" }}
                ></i>
              </a>
            </td>
          </tr>
          <tr>
            <td>Fran Wilson</td>
            <td>Human Resources</td>
            <td>(503) 555-9931</td>
            <td>
              <a
                class="add"
                title="Add"
                data-toggle="tooltip"
                style={{ marginRight: "30px" }}
              >
                <i
                  class="bi bi-pencil-fill"
                  style={{ font: "6rem", color: "grey" }}
                ></i>
              </a>
              <a class="delete" title="Delete" data-toggle="tooltip">
                <i
                  class="bi bi-trash-fill"
                  style={{ font: "2rem", color: "red" }}
                ></i>
              </a>
            </td>
          </tr>
          <tr>
            <td>John Doe</td>
            <td>Administration</td>
            <td>(171) 555-2222</td>
            <td>
              <a
                class="add"
                title="Add"
                data-toggle="tooltip"
                style={{ marginRight: "30px" }}
              >
                <i
                  class="bi bi-pencil-fill"
                  style={{ font: "6rem", color: "grey" }}
                ></i>
              </a>
              <a class="delete" title="Delete" data-toggle="tooltip">
                <i
                  class="bi bi-trash-fill"
                  style={{ font: "2rem", color: "red" }}
                ></i>
              </a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Customers;
