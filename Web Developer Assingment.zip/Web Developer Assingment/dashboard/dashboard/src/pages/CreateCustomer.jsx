import React from "react";
import "../pages/page-style.css";

const CreateCustomer = () => {
  return (
    <div>
      <h3>Create Customer</h3>
      <form>
        <div class="form-group">
          <input
            type="text"
            class="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Customer Name"
          />
        </div>
        <div class="form-group">
          <input
            type="number"
            class="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Age"
          />
        </div>
        <div class="form-group">
          <input
            type="date"
            class="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Date of Birth"
          />
        </div>
        <div class="form-group">
          <input
            type="text"
            class="form-control"
            id="exampleInputPassword1"
            placeholder="Address"
          />
        </div>
        <div class="form-group form-check"></div>
        <button class="btn" style={{width: "1055px", background: "var(--main-color)", color: "white"}}>
          Submit
        </button>
      </form>
    </div>
  );
};

export default CreateCustomer;
