const mongoose = require("mongoose")

//Table creation for the Blog
const CustomerSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Types.ObjectId,
        required: true,
        ref:'User'
    },
    customername: {
        type: String,
        required: true,
    },
    age: {
        type: String,
        required: true,
    },
    dateofbirth: {
        type: String,
        required: true,
    },
    address: {
        type: String,
        required: true,
    },
    photo: {
        type: String,
        required: true,
    }
}, {timestamps: true})

//updatedAt
//Created At

module.exports = mongoose.model("Customer", CustomerSchema)