const customerController = require("express").Router()
const Customer = require("../models/Customer")
const verifyToken = require('../middlewares/verifyToken')

//Get all the customer list
customerController.get('/getAll', async (req, res) => {
    try {
        const customers = await Customer.find({}).populate("userId", '-password')
        return res.status(200).json(customers)
    } catch (error) {
        return res.status(500).json(error)
    }
})

//Get relevant customer by click
customerController.get('/find/:id', async (req, res) => {
    try {
        const customer = await Customer.findById(req.params.id).populate("userId", 'password')
        await customer.save() //save and update views
        return res.status(200).json(customer)
    } catch (error) {
        return res.status(500).json(error)
    }
})

//Get featured customers
customerController.get('/featured', async (req, res) => {
    try {
        const customers = await Customer.find({ featured: true }).populate("userId", '-password').limit(3) //-password - password is not display in postman
        return res.status(200).json(customers)
    } catch (error) {
        return res.status(500).json(error)
    }
})

//Add a new customer
customerController.post('/', verifyToken, async (req, res) => {
    try {
        const customer = await Customer.create({ ...req.body, userId: req.user.id })
        return res.status(200).json(customer)
    } catch (error) {
        return res.status(500).json(error)
    }
})

//Update existing data in a customer
customerController.put('/updateCustomer/:id', async (req, res) => {
    try {
        

        const updateCustomer = await Customer
            .findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true })
            .populate('userId', '-password')

        return res.status(200).json(updateCustomer)
    } catch (error) {
        return res.status(500).json(error.message)
    }
})

//Delete a Customer
customerController.delete('/deleteCustomer/:id', async (req, res) => {
    try {
        
        await Customer.findByIdAndDelete(req.params.id)

        return res.status(200).json({ msg: 'Successfully delete the customer' })


    } catch (error) {
        return res.status(500).json(error)
    }
})

module.exports = customerController