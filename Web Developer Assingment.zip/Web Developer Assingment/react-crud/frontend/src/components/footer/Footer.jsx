import React from "react";
import classes from "./footer.module.css";
import logo from "../../assets/logo.png";
import { facebook, whatapp, insta, lindkin } from "../../utils/icons.js";

const Footer = () => {
  return (
    <footer>
      <div class="card text-center">
        
        <div class="card-footer text-muted">
          <div class="copyright">
            &copy; Copyright{" "}
            <strong>
              <span></span>
            </strong>
            . All Rights Reserved
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
