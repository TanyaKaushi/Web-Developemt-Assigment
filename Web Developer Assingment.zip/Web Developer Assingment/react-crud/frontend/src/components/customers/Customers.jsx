import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { request } from "../../utils/fetchApi";
import { format } from "timeago.js";
import { Link } from "react-router-dom";
import classes from "./customers.module.css";
import { MdOutlinePreview } from "react-icons/md";
import { AiFillLike } from "react-icons/ai";
import { FiArrowRight } from "react-icons/fi";
import { viewicon, like, user, written } from "../../utils/icons.js";
import Button from "../Button/Button";
import noblog from "../../assets/noblog.gif";
import { plus, signout } from "../../utils/icons.js";

const Categories = () => {
  const [customers, setCustomers] = useState([]);
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const [activeCategory, setActiveCategory] = useState("all");

  //Retrieve all the customers
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const data = await request("/customer/getAll", "GET");
        setCustomers(data);
        setFilteredCustomers(data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchCustomers();
  }, []);

  //Select the customers
  useEffect(() => {
    if (activeCategory === "all") {
      setFilteredCustomers(customers);
    } else {
    }
  }, [activeCategory]);

  return (
    <div className={classes.container}>
      <div className={classes.wrapper}>
        <h3>Customer List</h3>
        <div className={classes.categoriesAndCustomers}>
          {filteredCustomers?.length > 0 ? (
            <div className={classes.customers}>
              {filteredCustomers?.map((customer) => (
                <>
                  <div
                    class="row"
                    style={{ marginBottom: "170px", paddingLeft: "20px" }}
                  >
                    <div key={customer._id} className={classes.customer}>
                      <div
                        className={classes.group}
                        class="card-group"
                        style={{}}
                      >
                        <div
                          className="cardgroup"
                          class="card"
                          style={{
                            border: "2px solid #grey",
                            borderRadius: "25px",
                          }}
                        >
                          <div class="row">
                            <div class="col-3">
                              <Link
                                to={`/customerDetails/${customer?._id}`}
                                style={{ borderRadius: "20px" }}
                              >
                                <img
                                  src={`http://localhost:5000/images/${customer?.photo}`}
                                  style={{
                                    width: "105px",
                                    height: "105px",
                                    borderRadius: "50px 50px 50px 50px",
                                    padding: "10px",
                                  }}
                                />
                              </Link>
                            </div>
                            <div class="col-6">
                              <div class="card-body">
                                <h4>
                                  <b>{customer?.customername}</b>
                                </h4>

                                <Link
                                  to={`/customerDetails/${customer._id}`}
                                  className={classes.readMore}
                                >
                                  View details <FiArrowRight />
                                </Link>
                              </div>
                            </div>
                          </div>
                          <div
                            class="card-footer"
                            style={{
                              backgroundColor: "#grey",
                              borderRadius: "0px 0px 20px 20px",
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>
                    <div class="column"></div>
                    <div class="column"></div>
                  </div>
                </>
              ))}
            </div>
          ) : (
            <>
              <>
                <img
                  src={noblog}
                  alt="Third slide"
                  style={{ width: "200px", height: "200px", margin: "auto" }}
                />
                <h3 className={classes.noCustomersMessage}>
                  No any customers at the moment
                </h3>
                <h5 style={{ margin: "auto", marginTop: "50px" }}>
                  Like to add ?
                </h5>
              </>
              <div
                style={{
                  backgroundColor: "#349eff",
                  borderRadius: "30px",
                  margin: "auto",
                  width: "130px",
                  marginTop: "10px",
                }}
              >
                <Link to="/create">
                  <Button
                    name={"Create"}
                    icon={plus}
                    bPad={".8rem 1.6rem"}
                    bRad={"30px"}
                    color={"#fff"}
                  />
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Categories;
