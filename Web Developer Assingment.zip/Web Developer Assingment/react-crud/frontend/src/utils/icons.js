
export const trash = <i className="fa-solid fa-trash fa-beat"></i>
export const plus = <i className="fa-solid fa-plus fa-beat"></i>
export const viewicon = <i class="fa-sharp fa-solid fa-eye fa-beat" style={{ color: "grey", marginRight: "5px" }}></i>
export const like = <i class="fa-solid fa-heart fa-beat" style={{ color: "red", marginRight: "5px" }}></i>
export const signout = <i className="fa-solid fa-right-from-bracket fa-beat"></i>
export const logout = <i className="fa-solid fa-sign-out fa-beat"></i>
export const user = <i class="fa-regular fa-face-laugh-beam fa-beat" style={{ color: "grey", marginRight: "5px" }}></i>
export const written = <i class="fa-solid fa-pen fa-beat" style={{ color: "grey", marginRight: "5px" }}></i>
export const back = <i class="fa-solid fa-backward fa-beat"></i>
export const facebook = <i class="fa-brands fa-square-facebook fa-beat-fade" style={{ marginRight: "5px"}}></i>
export const whatapp = <i class="fa-brands fa-square-whatsapp fa-beat-fade" style={{ color: "#2bda5f", marginRight: "5px" }}></i>
export const insta =<i class="fa-brands fa-square-instagram fa-beat-fade" style={{ color: " #ee4920", marginRight: "5px" }}></i>
export const lindkin = <i class="fa-brands fa-linkedin fa-beat-fade" style={{ color: "blue", marginRight: "5px" }}></i>
export const edit = <i class="fa-solid fa-pen fa-beat" style={{ color: "white", marginRight: "5px" }}></i>