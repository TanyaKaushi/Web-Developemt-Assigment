import React from "react";
import { useState, Fragment } from "react";
import classes from "./customerDetails.module.css";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { request } from "../../utils/fetchApi";
import Footer from "../../components/footer/Footer";
import Navbar from "../../components/navbar/Navbar";
import { format } from "timeago.js";
import {
  AiFillEdit,
  AiFillLike,
  AiFillDelete,
  AiOutlineArrowRight,
  AiOutlineLike,
} from "react-icons/ai";
import { back } from "../../utils/icons.js";
import { edit, trash } from "../../utils/icons.js";
import Button from "../../components/Button/Button";
import { viewicon, like } from "../../utils/icons.js";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const CustomerDetails = () => {
  const [customerDetails, setCustomerDetails] = useState("");
  const { id } = useParams();
  const { user, token } = useSelector((state) => state.auth);
  const navigate = useNavigate();

//Get customer detail for relevant customer
  useEffect(() => {
    const fetchCustomerDetails = async () => {
      try {
        const data = await request(`/customer/find/${id}`, "GET");
        setCustomerDetails(data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchCustomerDetails();
  }, [id]);


  // delete
  const handleDeleteCustomer = async () => {
    try {
      await request(`/customer/deleteCustomer/${id}`, "DELETE");
      toast.success("Successfully delete the customer.");
      alert("Successfully Delete the customer");
      navigate("/home");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Navbar />
      <Fragment>
        <ToastContainer></ToastContainer>
        <div className={classes.container} style={{ marginTop: "200px" }}>
          <Link
            to="/home"
            className={classes.goBack}
            style={{ marginTop: "80px" }}
          >
            {back} Go Back
          </Link>
          <div className={classes.wrapper}>


          <img src={`http://localhost:5000/images/${customerDetails?.photo}`} />
            <h1 className={classes.title}>{customerDetails?.customername}</h1>
            <div className={classes.descAndLikesViews}>
              <p className={classes.desc}>Age : {customerDetails?.age}</p>
              <p className={classes.desc}>Date of Birth :{customerDetails?.dateofbirth}</p>
              <p className={classes.desc}>Address :{customerDetails?.address}</p>
            </div>

            <div className={classes.titleAndControls}>
              
                <div className={classes.controls}>
                  <Link
                    to={`/updateCustomer/${customerDetails?._id}`}
                    className={classes.edit}
                  >
                    <div style={{marginLeft: "20px"}}>{edit} <span>Edit</span></div>
                  </Link>
                  <div className={classes.delete}>
                    
                  <div style={{marginLeft: "20px"}}>{trash} <span onClick={handleDeleteCustomer}>Delete</span></div>
                  </div>
                </div>
            </div>
          </div>
        </div>
        <Footer />
      </Fragment>
    </>
  );
};

export default CustomerDetails;
