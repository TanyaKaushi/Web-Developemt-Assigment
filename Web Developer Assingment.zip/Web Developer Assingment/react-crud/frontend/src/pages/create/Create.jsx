import React, { useState, useContext, Fragment } from "react";
import Footer from "../../components/footer/Footer";
import Navbar from "../../components/navbar/Navbar";
import classes from "./create.module.css";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { AiOutlineCloseCircle } from "react-icons/ai";
import { request } from "../../utils/fetchApi";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { plus, signout } from "../../utils/icons.js";

const Create = () => {
  const [customername, setCustomername] = useState("");
  const [age, setAge] = useState("");
  const [dateofbirth, setDateofbirth] = useState("");
  const [address, setAddress] = useState("");
  const [img, setImg] = useState("");
  const navigate = useNavigate();
  const { token } = useSelector((state) => state.auth);

 

  const onChangeFile = (e) => {
    setImg(e.target.files[0]);
  };

  const handleCloseImg = () => {
    setImg(null);
  };

  const handleCreateCustomer = async (e) => {
    e.preventDefault();

    if (customername === "" || age === "" || dateofbirth === "" || address === "" ) {
      toast.error("All the fields are required");
      return;
    }

    try {
      const formData = new FormData();

      let filename = null;
      if (img) {
        filename = crypto.randomUUID() + img.name;
        formData.append("filename", filename);
        formData.append("image", img);

        await fetch(`http://localhost:5000/upload`, {
          method: "POST",
          body: formData,
        });
        toast.success("Success");
        alert("Posted");
      } else {
        return;
      }

      const options = {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      };

      const body = {
        customername,
        age,
        dateofbirth,
        address,
        photo: filename,
      };

      const data = await request("/customer", "POST", options, body);
      navigate(`/customerDetails/${data._id}`);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Fragment>
      <ToastContainer></ToastContainer>
      <Navbar />
      <div className={classes.container} style={{ marginTop: "80px" }}>
        <div className={classes.wrapper}>
          <h2 className={classes.title} style={{ marginTop: "30px" }}>
            Create Customer
          </h2>
          <form onSubmit={handleCreateCustomer} encType="multipart/form-data">
            <div className={classes.inputWrapper}>
              {/* <label>Title: </label> */}
              <input
                type="text"
                placeholder="Customer Name..."
                className={classes.input}
                onChange={(e) => setCustomername(e.target.value)}
              />
            </div>
            <div className={classes.inputWrapper}>
              {/* <label>Description: </label> */}
              <input
                type="number"
                placeholder="Age..."
                className={classes.input}
                onChange={(e) => setAge(e.target.value)}
              />
            </div>
            <div className={classes.inputWrapper}>
              {/* <label>Description: </label> */}
              <input
                type="date"
                placeholder="Date of Birth..."
                className={classes.input}
                onChange={(e) => setDateofbirth(e.target.value)}
              />
            </div>
            <div className={classes.inputWrapper}>
              {/* <label>Description: </label> */}
              <input
                type="text"
                placeholder="Address..."
                className={classes.input}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>
            <div className={classes.inputWrapperImg}>
              <label htmlFor="image" className={classes.labelFileInput}>
                Image: <span>Upload here</span>
              </label>
              <input
                id="image"
                type="file"
                className={classes.input}
                onChange={onChangeFile}
                style={{ display: "none" }}
              />
              {img && (
                <p className={classes.imageName}>
                  {img.name}{" "}
                  <AiOutlineCloseCircle
                    className={classes.closeIcon}
                    onClick={() => handleCloseImg()}
                  />
                </p>
              )}
            </div>
            <div className={classes.buttonWrapper}>
              <button className={classes.btn} type="submit">
                {plus} Submit form
              </button>
            </div>
          </form>
        </div>
      </div>
      <Footer />
    </Fragment>
  );
};

export default Create;
