import React from "react";
import { useEffect, Fragment } from "react";
import { useState } from "react";
import { useSelector } from "react-redux";
import { useParams, useNavigate } from "react-router-dom";
import Footer from "../../components/footer/Footer";
import Navbar from "../../components/navbar/Navbar";
import { request } from "../../utils/fetchApi";
import classes from "./updateCustomer.module.css";
import { plus, signout } from "../../utils/icons.js";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UpdateCustomer = () => {
  const [customerDetails, setCustomerDetails] = useState("");
  const [customername, setCustomername] = useState("");
  const [age, setAge] = useState("");
  const [dateofbirth, setDateofbirth] = useState("");
  const [address, setAddress] = useState("");
  const { token } = useSelector((state) => state.auth);
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    const fetchCustomerDetails = async () => {
      try {
        const options = { Authorization: `Bearer ${token}` };
        const data = await request(`/customer/find/${id}`, "GET", options);
        setCustomerDetails(data);
        setCustomername(data.customername);
        setAge(data.age);
        setDateofbirth(data.dateofbirth);
        setAddress(data.address);
      } catch (error) {
        console.error(error);
      }
    };
    fetchCustomerDetails();
  }, [id]);

  const handleUpdateCustomer = async (e) => {
    e.preventDefault();

    try {
      const options = {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      };
      await request(`/customer/updateCustomer/${id}`, "PUT", options, {
        customername,
        age,
        dateofbirth,
        address
      });
      toast.success("Successfully updated the customer");
      alert("Updated Successfully");
      navigate(`/customerDetails/${id}`);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Navbar />
      <Fragment>
        <ToastContainer></ToastContainer>
        <div className={classes.container}>
          <div className={classes.wrapper}>
            <h2>Update Customer</h2>
            <form onSubmit={handleUpdateCustomer}>
              <input
                type="text"
                placeholder="Customer Name..."
                value={customername}
                onChange={(e) => setCustomername(e.target.value)}
              />
              <input
                type="number"
                placeholder="Age..."
                value={age}
                onChange={(e) => setAge(e.target.value)}
              />
              <input
                type="date"
                placeholder="Date..."
                value={dateofbirth}
                onChange={(e) => setDateofbirth(e.target.value)}
              />
              <input
                type="text"
                placeholder="Address..."
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
              <button className={classes.btn} type="submit">{plus} Update</button>
            </form>
          </div>
        </div>
        <Footer />
      </Fragment>
    </>
  );
};

export default UpdateCustomer;
